var class_dataset_manipulator =
[
    [ "rotationSpeed", "class_dataset_manipulator.html#a3bca56bd1a639c2dfaa553556280d85f", null ],
    [ "targetObject", "class_dataset_manipulator.html#a6338515dc80ca3e4ba1935dd450115f7", null ],
    [ "translationSpeed", "class_dataset_manipulator.html#a241e0fb4aab49dedf99db1c773c74a60", null ],
    [ "zoomSpeed", "class_dataset_manipulator.html#aaee98228fc94b17b667004b6609808e4", null ]
];