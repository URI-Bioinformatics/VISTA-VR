var class_dataset_metadata_container =
[
    [ "DatasetMetadataContainer", "class_dataset_metadata_container.html#acef0f8f952ad5a63c0aa69d0078aa057", null ],
    [ "ClusterCount", "class_dataset_metadata_container.html#adf5a58aa62bd8ad62d1a4d283a85c1b3", null ],
    [ "DatasetName", "class_dataset_metadata_container.html#aaf9ab0b0f7a883587d2427cc053fd044", null ],
    [ "LayerResolution", "class_dataset_metadata_container.html#a13f5fc015d988396f659bc6739e7f1d3", null ],
    [ "Layers", "class_dataset_metadata_container.html#a89a24f7f3404781e59f230f14c98b5d0", null ],
    [ "NormalizationFactor", "class_dataset_metadata_container.html#a62179dd90832860c208afb63cf1969cb", null ]
];