var struct_csv_data_loader_1_1_search_job =
[
    [ "Execute", "struct_csv_data_loader_1_1_search_job.html#a060bc51841b1f4f1061c8695b15d76c6", null ],
    [ "buffer", "struct_csv_data_loader_1_1_search_job.html#a4d0b375af7520b3b2c9a8e35b065d334", null ],
    [ "records", "struct_csv_data_loader_1_1_search_job.html#ab1a50342fee8cf557ed1240b0b914edb", null ],
    [ "results", "struct_csv_data_loader_1_1_search_job.html#a8d1d06b56ea9a5290a7832891dded92a", null ],
    [ "target", "struct_csv_data_loader_1_1_search_job.html#a5f899ca2dc74dfe223e224630365d67d", null ]
];