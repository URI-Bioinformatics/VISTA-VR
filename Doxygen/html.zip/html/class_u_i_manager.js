var class_u_i_manager =
[
    [ "ImportImageLayer", "class_u_i_manager.html#a83fed7d6ef855cf0941d75283567b0a8", null ],
    [ "ToggleObject", "class_u_i_manager.html#aa5500894cdf6369dbe021b52abe31a74", null ]
];