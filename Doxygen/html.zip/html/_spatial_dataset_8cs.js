var _spatial_dataset_8cs =
[
    [ "SpatialDataset", "class_spatial_dataset.html", "class_spatial_dataset" ]
];