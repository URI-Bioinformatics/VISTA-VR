var class_layer =
[
    [ "DataType", "class_layer.html#a2a85306873f9ad7d104518724c57f9d6", [
      [ "Cluster", "class_layer.html#a2a85306873f9ad7d104518724c57f9d6a249694a485fc5d3289c38986b4f8e887", null ],
      [ "Image", "class_layer.html#a2a85306873f9ad7d104518724c57f9d6abe53a0541a6d36f6ecb879fa2c584b08", null ]
    ] ],
    [ "Layer", "class_layer.html#a25c30b429ec1f33bebaa8907cfc2b773", null ],
    [ "Layer", "class_layer.html#ab69f2865bac842c5d00abbb89f0bb1d8", null ],
    [ "Layer", "class_layer.html#a35e8a10c27f43c45eef48c49a1c40b2a", null ],
    [ "AssociatedFileName", "class_layer.html#a1a83bb593b9a078faf509f8a69db1f6d", null ],
    [ "Color", "class_layer.html#a3f38fe47fa6b99e74582dcd7652a7e11", null ],
    [ "Index", "class_layer.html#a237541099987151365176d7f8f729c84", null ],
    [ "LayerGameObject", "class_layer.html#a185f8b1fb3eebfb10e9f4b08f0277314", null ],
    [ "LayerRenderTexture", "class_layer.html#ac4cc04f73961cfd56a9252708a5d744c", null ],
    [ "LayerTexture2D", "class_layer.html#af23e02bfa060e70ba6290dbaba21b39c", null ],
    [ "LayerType", "class_layer.html#a255a546bed30554d274ffaf1f3038b30", null ],
    [ "LayerUIGameObject", "class_layer.html#acdb4e33709448d8dec9c9e698f967e93", null ],
    [ "LayerUIScript", "class_layer.html#a7f421a1009e95a5158e4af04925096bc", null ],
    [ "Name", "class_layer.html#a03e17434b6e3cf28e3dfa1886f3f9ccb", null ]
];