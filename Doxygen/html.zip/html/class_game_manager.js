var class_game_manager =
[
    [ "Mode", "class_game_manager.html#a39966b770e4f2d17b08e17372cf9498f", [
      [ "VR", "class_game_manager.html#a39966b770e4f2d17b08e17372cf9498faef8a9f751393cecaf3e811c30ee3e756", null ],
      [ "Immersive", "class_game_manager.html#a39966b770e4f2d17b08e17372cf9498fa7a7f14a4e02b9313d1586dda7a6e914b", null ],
      [ "Flat", "class_game_manager.html#a39966b770e4f2d17b08e17372cf9498fa745e3db6a7ffd50e1a72b39482f0882d", null ]
    ] ],
    [ "SetGameMode", "class_game_manager.html#a19f5655299c5439b688ffea329f3afee", null ],
    [ "GameMode", "class_game_manager.html#a587537b9a27c4ef87a2e15da4ddfcc76", null ]
];