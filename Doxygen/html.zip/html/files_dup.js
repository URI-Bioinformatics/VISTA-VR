var files_dup =
[
    [ "DatasetSystem", "dir_5d570d7d23b1ef0be014ef0786dfc688.html", "dir_5d570d7d23b1ef0be014ef0786dfc688" ],
    [ "New DatasetMetadataManagement", "dir_2a80f03d93e3d57c248d527f43bb40f6.html", "dir_2a80f03d93e3d57c248d527f43bb40f6" ],
    [ "DatasetManipulator.cs", "_dataset_manipulator_8cs.html", "_dataset_manipulator_8cs" ],
    [ "DatasetMetadata.cs", "_dataset_metadata_8cs.html", "_dataset_metadata_8cs" ],
    [ "DatasetMetadataManager.cs", "_dataset_metadata_manager_8cs.html", null ],
    [ "GameManager.cs", "_game_manager_8cs.html", "_game_manager_8cs" ],
    [ "LayerEvents.cs", "_layer_events_8cs.html", "_layer_events_8cs" ],
    [ "LayerInfoPanel.cs", "_layer_info_panel_8cs.html", "_layer_info_panel_8cs" ],
    [ "LayerManager.cs", "_layer_manager_8cs.html", "_layer_manager_8cs" ],
    [ "Options.cs", "_options_8cs.html", "_options_8cs" ],
    [ "RenderTextureSaver.cs", "_render_texture_saver_8cs.html", null ],
    [ "TabGroup.cs", "_tab_group_8cs.html", "_tab_group_8cs" ],
    [ "TextureLoader.cs", "_texture_loader_8cs.html", null ],
    [ "TransformsButtons.cs", "_transforms_buttons_8cs.html", "_transforms_buttons_8cs" ],
    [ "UIManager.cs", "_u_i_manager_8cs.html", "_u_i_manager_8cs" ],
    [ "WorldSpaceUIClicker.cs", "_world_space_u_i_clicker_8cs.html", "_world_space_u_i_clicker_8cs" ]
];