var class_csv_to_binary_converter =
[
    [ "batchLines", "class_csv_to_binary_converter.html#a4a079ed4a5328e78d98852c12e651c9e", null ]
];