var searchData=
[
  ['g_0',['G',['../struct_serializable_color.html#adfd134289d340e9330ac6f24758c341b',1,'SerializableColor']]],
  ['gamemode_1',['GameMode',['../class_game_manager.html#a587537b9a27c4ef87a2e15da4ddfcc76',1,'GameManager']]]
];
