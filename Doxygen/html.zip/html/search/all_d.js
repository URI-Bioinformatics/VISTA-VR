var searchData=
[
  ['name_0',['Name',['../class_layer.html#a03e17434b6e3cf28e3dfa1886f3f9ccb',1,'Layer']]],
  ['normalizationfactor_1',['NormalizationFactor',['../class_dataset_metadata_container.html#a62179dd90832860c208afb63cf1969cb',1,'DatasetMetadataContainer']]],
  ['normalizationfactor_2',['normalizationFactor',['../class_dataset_metadata.html#a16b76479688b028a56c80e50944e013e',1,'DatasetMetadata.normalizationFactor'],['../class_cell_spawn_manager.html#abf01aa073f8d470efaa64be1c45e75f9',1,'CellSpawnManager.normalizationFactor'],['../class_spatial_dataset.html#ada7858cf2b4252485a05470980565649',1,'SpatialDataset.normalizationFactor']]],
  ['nuclength_3',['nucLength',['../struct_csv_data_loader_1_1_record.html#a111ad6a9de04c84340fa8287f30be4b7',1,'CsvDataLoader::Record']]],
  ['nucoffset_4',['nucOffset',['../struct_csv_data_loader_1_1_record.html#aaedf454385319616973025ab002c269e',1,'CsvDataLoader::Record']]]
];
