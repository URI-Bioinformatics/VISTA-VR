var searchData=
[
  ['getclusterids_0',['GetClusterIDs',['../class_spatial_dataset.html#a796ebc8e5a19c69b0e7f9200c742fcdb',1,'SpatialDataset']]],
  ['getdatamanipsensitivity_1',['GetDataManipSensitivity',['../class_options.html#a8c10da38d4d57dfce10de23566ccb793',1,'Options']]],
  ['getinverseclusterids_2',['GetInverseClusterIDs',['../class_spatial_dataset.html#ab900638345e58ec8ae04f0d3f1f3bc75',1,'SpatialDataset']]]
];
