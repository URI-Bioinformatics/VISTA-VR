var searchData=
[
  ['darkmode_0',['DarkMode',['../class_options.html#ae34d2e4283cfb9819fe7dc7b399a158dacdc1da9550af69ba892772f9d118c6ba',1,'Options']]]
];
