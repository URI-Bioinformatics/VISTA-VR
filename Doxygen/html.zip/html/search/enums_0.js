var searchData=
[
  ['datatype_0',['DataType',['../class_layer.html#a2a85306873f9ad7d104518724c57f9d6',1,'Layer']]]
];
