var searchData=
[
  ['dataconverter_2ecs_0',['DataConverter.cs',['../_data_converter_8cs.html',1,'']]],
  ['datasetfilebrowser_2ecs_1',['DatasetFilebrowser.cs',['../_dataset_filebrowser_8cs.html',1,'']]],
  ['datasetmanipulator_2ecs_2',['DatasetManipulator.cs',['../_dataset_manipulator_8cs.html',1,'']]],
  ['datasetmetadata_2ecs_3',['DatasetMetadata.cs',['../_dataset_metadata_8cs.html',1,'']]],
  ['datasetmetadata_5fnew_2ecs_4',['DatasetMetadata_New.cs',['../_dataset_metadata___new_8cs.html',1,'']]],
  ['datasetmetadatamanager_2ecs_5',['DatasetMetadataManager.cs',['../_dataset_metadata_manager_8cs.html',1,'']]],
  ['datasetmetadatamanager_5fjson_2ecs_6',['DatasetMetadataManager_JSON.cs',['../_dataset_metadata_manager___j_s_o_n_8cs.html',1,'']]]
];
