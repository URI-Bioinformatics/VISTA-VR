var searchData=
[
  ['lightmode_0',['LightMode',['../class_options.html#ae34d2e4283cfb9819fe7dc7b399a158da3cd79026f235faec4421e36de174726c',1,'Options']]]
];
