var searchData=
[
  ['record_0',['Record',['../struct_csv_data_loader_1_1_record.html',1,'CsvDataLoader']]]
];
