var searchData=
[
  ['zoomspeed_0',['zoomSpeed',['../class_dataset_manipulator.html#aaee98228fc94b17b667004b6609808e4',1,'DatasetManipulator']]]
];
