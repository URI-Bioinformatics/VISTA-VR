var searchData=
[
  ['importimagelayerevent_0',['ImportImageLayerEvent',['../class_layer_events.html#acf58bb6866927863124afe9133cea622',1,'LayerEvents']]],
  ['index_1',['Index',['../class_layer.html#a237541099987151365176d7f8f729c84',1,'Layer.Index'],['../class_layer_data.html#af3baf82cf8e4f3ab55d861eb50f340b3',1,'LayerData.Index']]],
  ['indices_2',['indices',['../class_dataset_metadata.html#accc74b563cb9c992fa4c44a9533d10b1',1,'DatasetMetadata']]],
  ['instance_3',['Instance',['../class_game_manager.html#ad3e717f4fb0f378b969f4457de81f23e',1,'GameManager.Instance'],['../class_layer_manager.html#a7b03f9da52ffc1f25960b0faad5e31bf',1,'LayerManager.Instance'],['../class_options.html#abd6ea4e7a816c7c7ca4037b451d7f6b8',1,'Options.Instance']]],
  ['inverseclusterids_4',['InverseClusterIDs',['../class_spatial_dataset.html#a1fe816437d7c1ebcbfd0974196541009',1,'SpatialDataset']]]
];
