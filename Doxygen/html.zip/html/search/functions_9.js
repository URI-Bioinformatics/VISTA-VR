var searchData=
[
  ['movelayer_0',['MoveLayer',['../class_layer_info_panel.html#aa9db1666178ab58fed44ed7eae3aa390',1,'LayerInfoPanel']]],
  ['movelayerpos_1',['MoveLayerPos',['../class_layer_manager.html#aa87d4408d428b2ec72923ed45fa371ec',1,'LayerManager']]]
];
