var searchData=
[
  ['r_0',['R',['../struct_serializable_color.html#a1ffa5d1faa40c07729caba2b4f7a77c1',1,'SerializableColor']]],
  ['records_1',['records',['../struct_csv_data_loader_1_1_search_job.html#ab1a50342fee8cf557ed1240b0b914edb',1,'CsvDataLoader::SearchJob']]],
  ['resetview_2',['ResetView',['../class_layer_events.html#a425a8cb9e952b5964e07ef398de50c8d',1,'LayerEvents']]],
  ['resolution_3',['resolution',['../class_spatial_dataset.html#a1e93f42bfbb8473ec3d11d8a1f33a20e',1,'SpatialDataset']]],
  ['results_4',['results',['../struct_csv_data_loader_1_1_search_job.html#a8d1d06b56ea9a5290a7832891dded92a',1,'CsvDataLoader::SearchJob']]],
  ['rotationspeed_5',['rotationSpeed',['../class_dataset_manipulator.html#a3bca56bd1a639c2dfaa553556280d85f',1,'DatasetManipulator']]]
];
