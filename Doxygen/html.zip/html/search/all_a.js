var searchData=
[
  ['key_5fclustercount_0',['Key_ClusterCount',['../class_dataset_metadata.html#a74dabc97524df22c32f0d06b7b49ef5c',1,'DatasetMetadata']]],
  ['key_5fdatasetname_1',['Key_DatasetName',['../class_dataset_metadata.html#a6b99c32f7422a812cbb30343f6dc3de7',1,'DatasetMetadata']]],
  ['key_5findices_2',['Key_Indices',['../class_dataset_metadata.html#acb9123df437e5597110bf90c160089dc',1,'DatasetMetadata']]],
  ['key_5flayernames_3',['Key_LayerNames',['../class_dataset_metadata.html#a74731a965d9b8bf4637adc8335fe979c',1,'DatasetMetadata']]],
  ['key_5flayerresolution_4',['Key_LayerResolution',['../class_dataset_metadata.html#a4f9460fd474f3d5496e8b4d45b03607b',1,'DatasetMetadata']]],
  ['key_5flayertypes_5',['Key_LayerTypes',['../class_dataset_metadata.html#ab1a3ce9aa0d0492f83c441087fc220fe',1,'DatasetMetadata']]],
  ['key_5fnormalizationfactor_6',['Key_NormalizationFactor',['../class_dataset_metadata.html#a0c7bdd2fc710ace8bbdd9bcbaf24e14f',1,'DatasetMetadata']]]
];
