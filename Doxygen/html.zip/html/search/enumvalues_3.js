var searchData=
[
  ['image_0',['Image',['../class_layer.html#a2a85306873f9ad7d104518724c57f9d6abe53a0541a6d36f6ecb879fa2c584b08',1,'Layer']]],
  ['immersive_1',['Immersive',['../class_game_manager.html#a39966b770e4f2d17b08e17372cf9498fa7a7f14a4e02b9313d1586dda7a6e914b',1,'GameManager']]]
];
