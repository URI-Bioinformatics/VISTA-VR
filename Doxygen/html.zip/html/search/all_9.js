var searchData=
[
  ['image_0',['Image',['../class_layer.html#a2a85306873f9ad7d104518724c57f9d6abe53a0541a6d36f6ecb879fa2c584b08',1,'Layer']]],
  ['immersive_1',['Immersive',['../class_game_manager.html#a39966b770e4f2d17b08e17372cf9498fa7a7f14a4e02b9313d1586dda7a6e914b',1,'GameManager']]],
  ['importimagelayer_2',['ImportImageLayer',['../class_u_i_manager.html#a83fed7d6ef855cf0941d75283567b0a8',1,'UIManager']]],
  ['importimagelayerevent_3',['ImportImageLayerEvent',['../class_layer_events.html#acf58bb6866927863124afe9133cea622',1,'LayerEvents']]],
  ['index_4',['Index',['../class_layer.html#a237541099987151365176d7f8f729c84',1,'Layer.Index'],['../class_layer_data.html#af3baf82cf8e4f3ab55d861eb50f340b3',1,'LayerData.Index']]],
  ['indices_5',['indices',['../class_dataset_metadata.html#accc74b563cb9c992fa4c44a9533d10b1',1,'DatasetMetadata']]],
  ['initialize_6',['Initialize',['../class_cell_spawn_manager.html#a610d7cf7d768b9dceec25cfadb7f92b6',1,'CellSpawnManager.Initialize()'],['../class_e_c_s_data_manipulator.html#a60d6103ac2d8b3a4bb20491610c8ebdf',1,'ECSDataManipulator.Initialize()']]],
  ['instance_7',['Instance',['../class_game_manager.html#ad3e717f4fb0f378b969f4457de81f23e',1,'GameManager.Instance'],['../class_layer_manager.html#a7b03f9da52ffc1f25960b0faad5e31bf',1,'LayerManager.Instance'],['../class_options.html#abd6ea4e7a816c7c7ca4037b451d7f6b8',1,'Options.Instance']]],
  ['inverseclusterids_8',['InverseClusterIDs',['../class_spatial_dataset.html#a1fe816437d7c1ebcbfd0974196541009',1,'SpatialDataset']]]
];
