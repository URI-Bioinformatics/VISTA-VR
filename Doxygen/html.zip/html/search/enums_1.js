var searchData=
[
  ['mode_0',['Mode',['../class_game_manager.html#a39966b770e4f2d17b08e17372cf9498f',1,'GameManager']]]
];
