var struct_cluster_control_request =
[
    [ "Enable", "struct_cluster_control_request.html#a42bcf59e2c8d0f31fc8c487535b4cbca", null ],
    [ "TargetClusterIndex", "struct_cluster_control_request.html#a2e6c182aaade8da2a358d78cd4dca67a", null ]
];