var struct_csv_data_loader_1_1_record =
[
    [ "barcodeLength", "struct_csv_data_loader_1_1_record.html#a64ea26aba891e9a820ba637c2513c2a4", null ],
    [ "barcodeOffset", "struct_csv_data_loader_1_1_record.html#a47a1f5a70565a185242ae391c35ad95b", null ],
    [ "nucLength", "struct_csv_data_loader_1_1_record.html#a111ad6a9de04c84340fa8287f30be4b7", null ],
    [ "nucOffset", "struct_csv_data_loader_1_1_record.html#aaedf454385319616973025ab002c269e", null ],
    [ "protLength", "struct_csv_data_loader_1_1_record.html#a1a609f277956d091bb233f1129ea7137", null ],
    [ "protOffset", "struct_csv_data_loader_1_1_record.html#aafc5451aa134ecca26601831ed4b7545", null ]
];