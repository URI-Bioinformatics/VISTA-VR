var _dataset_metadata___new_8cs =
[
    [ "SerializableColor", "struct_serializable_color.html", "struct_serializable_color" ],
    [ "LayerData", "class_layer_data.html", "class_layer_data" ],
    [ "DatasetMetadataContainer", "class_dataset_metadata_container.html", "class_dataset_metadata_container" ]
];