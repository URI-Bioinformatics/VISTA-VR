var _csv_data_loader_8cs =
[
    [ "CsvDataLoader.Record", "struct_csv_data_loader_1_1_record.html", "struct_csv_data_loader_1_1_record" ],
    [ "CsvDataLoader.SearchJob", "struct_csv_data_loader_1_1_search_job.html", "struct_csv_data_loader_1_1_search_job" ]
];