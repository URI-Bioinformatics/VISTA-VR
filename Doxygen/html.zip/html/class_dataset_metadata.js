var class_dataset_metadata =
[
    [ "clusterCount", "class_dataset_metadata.html#a11f99ff52e043a42aabef66a0b21bd02", null ],
    [ "datasetName", "class_dataset_metadata.html#a865f09cb9358ee8c119854790c1279b2", null ],
    [ "indices", "class_dataset_metadata.html#accc74b563cb9c992fa4c44a9533d10b1", null ],
    [ "layerNames", "class_dataset_metadata.html#ac74ffbe4b9c203807ff413d078b6a9c7", null ],
    [ "layerResolution", "class_dataset_metadata.html#ae288e4c62f2ed08da671ec7ffe45020f", null ],
    [ "layerTypes", "class_dataset_metadata.html#ae760f308a61b21342d5347cd87a9dc18", null ],
    [ "normalizationFactor", "class_dataset_metadata.html#a16b76479688b028a56c80e50944e013e", null ]
];