var struct_cell_data =
[
    [ "CellData", "struct_cell_data.html#a4958c5470f1461e7bf4be3b7ed9613b2", null ],
    [ "CellId", "struct_cell_data.html#a9ac4773c30bb5d4f060de3bffcf0ca59", null ],
    [ "ClusterId", "struct_cell_data.html#a4fd5685517a62d3f10bc9918cdac76f4", null ],
    [ "Position", "struct_cell_data.html#ab94453c322ae6049896e10d409bc8ccb", null ]
];