var class_cluster_control_system =
[
    [ "OnCreate", "class_cluster_control_system.html#aacd653ef57583aacd86f0ffc3b58ee5e", null ],
    [ "OnUpdate", "class_cluster_control_system.html#ad7eabdccc7036beec963b017ab35166b", null ]
];