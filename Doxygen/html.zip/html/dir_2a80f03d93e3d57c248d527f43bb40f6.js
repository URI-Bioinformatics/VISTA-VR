var dir_2a80f03d93e3d57c248d527f43bb40f6 =
[
    [ "DatasetMetadata_New.cs", "_dataset_metadata___new_8cs.html", "_dataset_metadata___new_8cs" ],
    [ "DatasetMetadataManager_JSON.cs", "_dataset_metadata_manager___j_s_o_n_8cs.html", null ]
];