var class_options =
[
    [ "UIColorMode", "class_options.html#ae34d2e4283cfb9819fe7dc7b399a158d", [
      [ "LightMode", "class_options.html#ae34d2e4283cfb9819fe7dc7b399a158da3cd79026f235faec4421e36de174726c", null ],
      [ "DarkMode", "class_options.html#ae34d2e4283cfb9819fe7dc7b399a158dacdc1da9550af69ba892772f9d118c6ba", null ]
    ] ],
    [ "GetDataManipSensitivity", "class_options.html#a8c10da38d4d57dfce10de23566ccb793", null ],
    [ "SetSkybox", "class_options.html#aa50ce53edbfc937dce694ee782b40b96", null ],
    [ "SetUIElementColors", "class_options.html#a443b400dcad44618a034e66d9b7de2bd", null ],
    [ "_UIColorMode", "class_options.html#ace3835aeef763810c188f1f6f36ee859", null ],
    [ "darkModeButtonColorBlock", "class_options.html#a35bb87d051d8e452f9891db9c144b15b", null ],
    [ "darkModeToggleColorBlock", "class_options.html#a3c570e699693cb0f072c8af485492319", null ]
];