var class_layer_data =
[
    [ "LayerData", "class_layer_data.html#ae8432cdbc8ee682fa9e278d4e23ea9cf", null ],
    [ "LayerData", "class_layer_data.html#ac45c19e7eab3d76431ac07700cdf15c0", null ],
    [ "LayerData", "class_layer_data.html#a88c6c8753f90c33fa51f31c9f9985861", null ],
    [ "ToLayerObject", "class_layer_data.html#a4c35e8e9c3bc43b15d1f4e8f95184c47", null ],
    [ "Color", "class_layer_data.html#a0666ed7d36870bdea5b5f6da40d8e000", null ],
    [ "FileName", "class_layer_data.html#a52392f30c56f55aca00c7e494d4b414d", null ],
    [ "Index", "class_layer_data.html#af3baf82cf8e4f3ab55d861eb50f340b3", null ],
    [ "LayerName", "class_layer_data.html#abe4dc1b172b5edf8998f23ef69833395", null ],
    [ "LayerType", "class_layer_data.html#a4d5de28e476d1edebffaef8779bd879d", null ]
];