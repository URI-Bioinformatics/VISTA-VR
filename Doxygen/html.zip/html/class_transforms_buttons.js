var class_transforms_buttons =
[
    [ "ResetView", "class_transforms_buttons.html#a67644473682bbbcdff541c2eb1e0e3a1", null ],
    [ "ToggleCamType", "class_transforms_buttons.html#a16fbe39b2ec413395f93531ecaa61441", null ],
    [ "TopView", "class_transforms_buttons.html#aa366f14316002b00804eee502b4077fd", null ],
    [ "flatCam", "class_transforms_buttons.html#a07bf79775bb01d19fde8743e75cb18b5", null ]
];