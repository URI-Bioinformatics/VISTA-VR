var struct_cell_component =
[
    [ "CellId", "struct_cell_component.html#a2736e506f7a70979cd6d731b3d4a3d98", null ],
    [ "ClusterId", "struct_cell_component.html#a00a59968908cb10a01091df22fae662b", null ]
];