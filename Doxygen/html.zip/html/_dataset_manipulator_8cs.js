var _dataset_manipulator_8cs =
[
    [ "DatasetManipulator", "class_dataset_manipulator.html", "class_dataset_manipulator" ]
];