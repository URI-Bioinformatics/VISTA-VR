var class_e_c_s_data_manipulator =
[
    [ "DisableCluster", "class_e_c_s_data_manipulator.html#a2ebe7ec6221de179a724a051f5c25e4c", null ],
    [ "EnableCluster", "class_e_c_s_data_manipulator.html#a7d15c0ad930e2d40dd6d084963a7819f", null ],
    [ "Initialize", "class_e_c_s_data_manipulator.html#a60d6103ac2d8b3a4bb20491610c8ebdf", null ]
];