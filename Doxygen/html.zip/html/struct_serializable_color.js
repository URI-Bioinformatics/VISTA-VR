var struct_serializable_color =
[
    [ "SerializableColor", "struct_serializable_color.html#ac1530f1b8e2abb696e34b39655be1c9c", null ],
    [ "ToUnityColor", "struct_serializable_color.html#aa345c5b2ec80038378da5b2c4b54bff7", null ],
    [ "B", "struct_serializable_color.html#a147cc24aa46eaf7296446a407a500fed", null ],
    [ "G", "struct_serializable_color.html#adfd134289d340e9330ac6f24758c341b", null ],
    [ "R", "struct_serializable_color.html#a1ffa5d1faa40c07729caba2b4f7a77c1", null ]
];